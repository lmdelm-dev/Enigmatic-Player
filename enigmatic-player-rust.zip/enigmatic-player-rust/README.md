# Enigmatic Player (Rust)

A pixel-style terminal music player. Real audio, a real spectrum visualizer, seekable progress bar, block volume, speed, live reverb, search, 33 themes, and a settings window. Made by Jamal Tiliouan. Open source.

> Status: first version, written without a compiler. Run `cargo check` first. If it reports errors, they should be small (version or API differences). See `AGENTS.md` for a prompt that fixes them.

## Requirements

- Rust (stable). Install from https://rustup.rs
- A terminal with true color and at least 80x28 characters
- Linux only: ALSA headers for audio output

```
# Debian / Ubuntu
sudo apt install libasound2-dev pkg-config
# Fedora
sudo dnf install alsa-lib-devel
```

Optional, for YouTube, SoundCloud and Bandcamp:

- `yt-dlp` (search and download)
- `ffmpeg` (converts downloads to mp3)

## Run

```
cargo run --release
```

On first start it scans `~/Music/enigmatic-player`. Change the folder in settings (`s`). Put music files there (mp3, flac, ogg, wav, m4a, aac).

## Keys

| Key | Action |
| --- | --- |
| `space` | Play or pause |
| `left` / `right` (or `h` / `l`) | Seek 5 seconds |
| `up` / `down` (or `k` / `j`) | Move in the list |
| `enter` | Play (local) or download and play (online) |
| `d` | Download only |
| `/` | Search. Local search filters live; online sources search on `enter` |
| `tab` | Hide or show the library |
| `1` to `4` | Source: local, YouTube, SoundCloud, Bandcamp |
| `-` / `=` | Volume |
| `m` | Mute |
| `[` / `]` | Slower and faster (also changes pitch, like tape) |
| `r` | Cycle reverb preset |
| `<` / `>` | Reverb amount |
| `n` / `p` | Next and previous |
| `s` | Settings |
| `q` | Quit |

Mouse: click or drag the progress bar, volume bar and reverb bar. Click the transport buttons, speed chips, reverb chips, sources, tracks (click a selected track to play), the library header, and the settings label.

## Settings

- **themes**: 33 themes, previewed live as you move through the list
- **local music**: the folder for your library and downloads
- **about**: version, author, shortcuts

Settings are saved to `config.json` in your config folder (`~/.config/enigmatic-player/` on Linux).

## Online sources

- YouTube and SoundCloud: choose the source, press `/`, type, press `enter`.
- Bandcamp has no search in yt-dlp. Paste a track or album URL after `/`.
- Pressing `enter` on a result downloads it into your music folder as mp3 and then plays it. Respect each service's terms of use.

## Project layout

| File | Purpose |
| --- | --- |
| `src/main.rs` | Terminal setup and main loop |
| `src/app.rs` | State, keyboard, mouse, background jobs |
| `src/ui.rs` | All drawing (ratatui) |
| `src/audio.rs` | Playback engine, live reverb, spectrum analyzer |
| `src/library.rs` | Folder scan, tags, yt-dlp search and download |
| `src/config.rs` | Saved settings |
| `src/themes.rs` | The 33 themes |
