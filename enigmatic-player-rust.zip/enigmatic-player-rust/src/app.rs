use std::sync::mpsc::{channel, Receiver, Sender};
use std::thread;

use ratatui::{
    crossterm::event::{KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind},
    layout::Rect,
    widgets::ListState,
};

use crate::audio::Engine;
use crate::config::{expand, Config};
use crate::library::{self, Provider, Track};
use crate::themes::{self, THEMES};

pub const REVERBS: [(&str, u32); 5] = [("off", 0), ("room", 25), ("hall", 45), ("cave", 65), ("space", 85)];
pub const SPEEDS: [f32; 6] = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
pub const NB_VOL: usize = 16;
pub const NB_RV: usize = 8;
pub const BANDS: usize = 14;
pub const PICKS: [&str; 4] = [
    "~/Music/enigmatic-player",
    "~/Music",
    "~/Downloads/music",
    "/mnt/media/music",
];

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    Normal,
    Search,
    Settings,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Btn {
    Prev,
    Back,
    Play,
    Fwd,
    Next,
}

pub enum Msg {
    Scanned(Vec<Track>),
    Found(Result<Vec<Track>, String>),
    Downloaded { res: Result<Track, String>, play: bool },
}

/// Clickable areas, refreshed on every draw.
#[derive(Default)]
pub struct Hit {
    pub progress: Rect,
    pub vol: Rect,
    pub mute: Rect,
    pub rv_bar: Rect,
    pub gear: Rect,
    pub lib_header: Rect,
    pub tracks: Rect,
    pub tracks_offset: usize,
    pub btns: Vec<(Rect, Btn)>,
    pub speeds: Vec<(Rect, f32)>,
    pub reverbs: Vec<(Rect, usize)>,
    pub sources: Vec<(Rect, usize)>,
}

pub struct App {
    pub cfg: Config,
    pub theme: usize,
    pub engine: Option<Engine>,
    pub local: Vec<Track>,
    pub remote: Vec<Track>,
    pub source: usize,
    pub sel: usize,
    pub list_state: ListState,
    pub pl: Vec<Track>,
    pub pl_idx: usize,
    pub now: Option<Track>,
    pub pos: f64,
    pub dur: f64,
    pub playing: bool,
    pub query: String,
    pub mode: Mode,
    pub lib_open: bool,
    pub bars: Vec<f32>,
    pub status: String,
    pub busy: bool,
    pub have_ytdlp: bool,
    pub set_tab: usize,
    pub theme_state: ListState,
    pub dir_input: String,
    pub dir_msg: Option<(String, bool)>,
    pub pick_i: usize,
    pub hit: Hit,
    pub quit: bool,
    tx: Sender<Msg>,
    rx: Receiver<Msg>,
}

fn inside(r: Rect, x: u16, y: u16) -> bool {
    x >= r.x && x < r.x + r.width && y >= r.y && y < r.y + r.height
}

fn frac(r: Rect, x: u16) -> f32 {
    if r.width == 0 {
        return 0.0;
    }
    ((x.saturating_sub(r.x)) as f32 / r.width as f32).clamp(0.0, 1.0)
}

impl App {
    pub fn new() -> App {
        let cfg = Config::load();
        let theme = themes::index_of(&cfg.theme);
        let (engine, engine_err) = match Engine::new() {
            Ok(e) => (Some(e), None),
            Err(e) => (None, Some(e)),
        };
        let (tx, rx) = channel();
        let mut app = App {
            dir_input: cfg.dir.clone(),
            cfg,
            theme,
            engine,
            local: Vec::new(),
            remote: Vec::new(),
            source: 0,
            sel: 0,
            list_state: ListState::default(),
            pl: Vec::new(),
            pl_idx: 0,
            now: None,
            pos: 0.0,
            dur: 0.0,
            playing: false,
            query: String::new(),
            mode: Mode::Normal,
            lib_open: true,
            bars: vec![0.0; BANDS],
            status: String::new(),
            busy: false,
            have_ytdlp: library::has_ytdlp(),
            set_tab: 0,
            theme_state: ListState::default(),
            dir_msg: None,
            pick_i: 0,
            hit: Hit::default(),
            quit: false,
            tx,
            rx,
        };
        app.apply_audio();
        app.rescan();
        if let Some(e) = engine_err {
            app.status = format!("no audio output: {e}");
        }
        app
    }

    pub fn save(&mut self) {
        self.cfg.theme = THEMES[self.theme].name.to_string();
        self.cfg.save();
    }

    // ---------- library ----------

    pub fn rescan(&mut self) {
        let dir = expand(&self.cfg.dir);
        let tx = self.tx.clone();
        self.status = format!("scanning {} ...", self.cfg.dir);
        thread::spawn(move || {
            let tracks = library::scan(&dir);
            let _ = tx.send(Msg::Scanned(tracks));
        });
    }

    pub fn list(&self) -> Vec<&Track> {
        if self.source == 0 {
            let q = self.query.to_lowercase();
            self.local
                .iter()
                .filter(|t| {
                    q.is_empty()
                        || t.title.to_lowercase().contains(&q)
                        || t.artist.to_lowercase().contains(&q)
                })
                .collect()
        } else {
            self.remote.iter().collect()
        }
    }

    fn fix_sel(&mut self) {
        let n = self.list().len();
        if n == 0 {
            self.sel = 0;
        } else if self.sel >= n {
            self.sel = n - 1;
        }
    }

    fn move_sel(&mut self, d: isize) {
        let n = self.list().len();
        if n == 0 {
            self.sel = 0;
            return;
        }
        self.sel = (self.sel as isize + d).clamp(0, n as isize - 1) as usize;
    }

    fn set_source(&mut self, i: usize) {
        if i >= Provider::ALL.len() {
            return;
        }
        self.source = i;
        self.sel = 0;
        if i != 0 && !self.have_ytdlp {
            self.status = "yt-dlp not found. Install it to use online sources.".into();
        } else if Provider::ALL[i] == Provider::Bandcamp {
            self.status = "bandcamp: press / and paste a track or album url".into();
        } else if i != 0 {
            self.status = "press / to search, then enter".into();
        } else {
            self.status.clear();
        }
    }

    fn start_search(&mut self) {
        if self.busy || self.query.trim().is_empty() {
            return;
        }
        if !self.have_ytdlp {
            self.status = "yt-dlp not found. Install it to use online sources.".into();
            return;
        }
        let provider = Provider::ALL[self.source];
        let is_url = self.query.starts_with("http://") || self.query.starts_with("https://");
        if provider == Provider::Bandcamp && !is_url {
            self.status = "bandcamp needs a track or album url".into();
            return;
        }
        let q = self.query.trim().to_string();
        let tx = self.tx.clone();
        self.busy = true;
        self.status = format!("searching {} ...", provider.name());
        thread::spawn(move || {
            let _ = tx.send(Msg::Found(library::search_remote(provider, &q)));
        });
    }

    fn download(&mut self, t: Track, play: bool) {
        if self.busy {
            self.status = "busy, wait for the current job".into();
            return;
        }
        let Some(url) = t.url.clone() else { return };
        let dir = expand(&self.cfg.dir);
        let tx = self.tx.clone();
        self.busy = true;
        self.status = format!("downloading: {} ...", t.title);
        thread::spawn(move || {
            let res = library::download(&url, &dir).map(|p| library::track_from_path(&p));
            let _ = tx.send(Msg::Downloaded { res, play });
        });
    }

    // ---------- playback ----------

    pub fn apply_audio(&mut self) {
        let v = if self.cfg.muted { 0.0 } else { self.cfg.vol };
        let (r, w, s) = (self.cfg.reverb, self.cfg.wet, self.cfg.speed);
        if let Some(e) = self.engine.as_mut() {
            e.set_volume(v);
            e.set_speed(s);
            e.set_reverb(r, w);
        }
    }

    fn play_track(&mut self, t: Track) {
        let Some(path) = t.path.clone() else {
            self.status = "this track has no local file yet (press d to download)".into();
            return;
        };
        let Some(engine) = self.engine.as_mut() else {
            self.status = "no audio output device".into();
            return;
        };
        match engine.play(&path) {
            Ok(()) => {
                self.pos = 0.0;
                self.dur = t.secs;
                self.now = Some(t);
                self.playing = true;
                self.status.clear();
            }
            Err(e) => self.status = format!("cannot play: {e}"),
        }
    }

    fn toggle_play(&mut self) {
        if self.now.is_none() {
            self.activate(true);
            return;
        }
        self.playing = !self.playing;
        let playing = self.playing;
        if let Some(e) = self.engine.as_mut() {
            if playing {
                e.resume();
            } else {
                e.pause();
            }
        }
    }

    fn next(&mut self, d: isize) {
        if self.pl.is_empty() {
            return;
        }
        let n = self.pl.len() as isize;
        let idx = (self.pl_idx as isize + d).rem_euclid(n) as usize;
        self.pl_idx = idx;
        let t = self.pl[idx].clone();
        self.play_track(t);
    }

    fn prev(&mut self) {
        if self.pos > 3.0 {
            self.seek_to(0.0);
        } else {
            self.next(-1);
        }
    }

    pub fn seek_to(&mut self, t: f64) {
        let Some(path) = self.now.as_ref().and_then(|n| n.path.clone()) else {
            return;
        };
        let t = if self.dur > 0.0 {
            t.clamp(0.0, (self.dur - 0.05).max(0.0))
        } else {
            t.max(0.0)
        };
        let ok = match self.engine.as_mut() {
            Some(e) => e.seek(&path, t),
            None => false,
        };
        if ok {
            self.pos = t;
        } else {
            self.status = "seek failed for this file".into();
        }
    }

    fn seek_by(&mut self, d: f64) {
        self.seek_to(self.pos + d);
    }

    fn set_vol(&mut self, v: f32) {
        self.cfg.vol = v.clamp(0.0, 1.0);
        self.cfg.muted = self.cfg.vol <= 0.0;
        self.apply_audio();
    }

    fn toggle_mute(&mut self) {
        self.cfg.muted = !self.cfg.muted;
        if !self.cfg.muted && self.cfg.vol <= 0.0 {
            self.cfg.vol = 0.5;
        }
        self.apply_audio();
    }

    fn set_speed(&mut self, s: f32) {
        self.cfg.speed = ((s.clamp(0.5, 2.0)) * 100.0).round() / 100.0;
        self.apply_audio();
    }

    fn set_wet(&mut self, w: u32) {
        let w = ((w.min(100) + 2) / 5) * 5;
        self.cfg.wet = w;
        if w == 0 {
            self.cfg.reverb = 0;
        } else if self.cfg.reverb == 0 {
            self.cfg.reverb = 1;
        }
        self.apply_audio();
    }

    fn set_reverb_preset(&mut self, i: usize) {
        let i = i.min(REVERBS.len() - 1);
        self.cfg.reverb = i;
        self.cfg.wet = REVERBS[i].1;
        self.apply_audio();
    }

    fn activate(&mut self, play: bool) {
        let (tracks, chosen) = {
            let l = self.list();
            (
                l.iter().map(|t| (*t).clone()).collect::<Vec<Track>>(),
                l.get(self.sel).map(|t| (*t).clone()),
            )
        };
        let Some(t) = chosen else { return };
        if self.source == 0 {
            if play {
                self.pl = tracks;
                self.pl_idx = self.sel;
                self.play_track(t);
            }
        } else {
            self.download(t, play);
        }
    }

    // ---------- per-frame ----------

    pub fn tick(&mut self, dt: f64) {
        while let Ok(m) = self.rx.try_recv() {
            match m {
                Msg::Scanned(t) => {
                    self.local = t;
                    self.status = format!("{} local tracks in {}", self.local.len(), self.cfg.dir);
                    self.fix_sel();
                }
                Msg::Found(r) => {
                    self.busy = false;
                    match r {
                        Ok(t) => {
                            self.status = format!("{} results. enter plays, d downloads", t.len());
                            self.remote = t;
                            self.sel = 0;
                        }
                        Err(e) => self.status = e,
                    }
                }
                Msg::Downloaded { res, play } => {
                    self.busy = false;
                    match res {
                        Ok(t) => {
                            self.status = format!("saved: {}", t.title);
                            if !self.local.iter().any(|x| x.path == t.path) {
                                self.local.push(t.clone());
                            }
                            if play {
                                self.pl = self.local.clone();
                                self.pl_idx = self.local.iter().position(|x| x.path == t.path).unwrap_or(0);
                                self.play_track(t);
                            }
                        }
                        Err(e) => self.status = e,
                    }
                }
            }
        }

        if self.playing && self.now.is_some() {
            self.pos += dt * self.cfg.speed as f64;
            let done = self.engine.as_ref().map(|e| e.finished()).unwrap_or(false);
            if done {
                self.next(1);
            }
        }

        let raw = match (&self.engine, self.playing) {
            (Some(e), true) => e.spectrum(BANDS),
            _ => vec![0.0; BANDS],
        };
        let decay = if self.playing { 0.45 + 0.5 * (self.cfg.wet as f32 / 100.0) } else { 0.3 };
        for (i, b) in self.bars.iter_mut().enumerate() {
            let v = raw.get(i).copied().unwrap_or(0.0);
            *b = v.max(*b * decay);
        }
    }

    // ---------- keyboard ----------

    pub fn on_key(&mut self, k: KeyEvent) {
        if k.modifiers.contains(KeyModifiers::CONTROL) && k.code == KeyCode::Char('c') {
            self.quit = true;
            return;
        }
        match self.mode {
            Mode::Normal => self.key_normal(k),
            Mode::Search => self.key_search(k),
            Mode::Settings => self.key_settings(k),
        }
    }

    fn key_normal(&mut self, k: KeyEvent) {
        match k.code {
            KeyCode::Char('q') => self.quit = true,
            KeyCode::Char('/') => self.mode = Mode::Search,
            KeyCode::Char('s') | KeyCode::Char(',') => self.open_settings(),
            KeyCode::Tab => self.lib_open = !self.lib_open,
            KeyCode::Char(' ') => self.toggle_play(),
            KeyCode::Left | KeyCode::Char('h') => self.seek_by(-5.0),
            KeyCode::Right | KeyCode::Char('l') => self.seek_by(5.0),
            KeyCode::Up | KeyCode::Char('k') => self.move_sel(-1),
            KeyCode::Down | KeyCode::Char('j') => self.move_sel(1),
            KeyCode::Enter => self.activate(true),
            KeyCode::Char('d') => self.activate(false),
            KeyCode::Char('-') => self.set_vol(self.cfg.vol - 0.05),
            KeyCode::Char('=') | KeyCode::Char('+') => self.set_vol(self.cfg.vol + 0.05),
            KeyCode::Char('m') => self.toggle_mute(),
            KeyCode::Char('[') => self.set_speed(self.cfg.speed - 0.05),
            KeyCode::Char(']') => self.set_speed(self.cfg.speed + 0.05),
            KeyCode::Char('r') => self.set_reverb_preset((self.cfg.reverb + 1) % REVERBS.len()),
            KeyCode::Char('<') => self.set_wet(self.cfg.wet.saturating_sub(5)),
            KeyCode::Char('>') => self.set_wet(self.cfg.wet + 5),
            KeyCode::Char('n') => self.next(1),
            KeyCode::Char('p') => self.prev(),
            KeyCode::Char(c @ '1'..='4') => self.set_source(c as usize - '1' as usize),
            _ => {}
        }
    }

    fn key_search(&mut self, k: KeyEvent) {
        match k.code {
            KeyCode::Esc => {
                self.query.clear();
                self.mode = Mode::Normal;
                self.sel = 0;
            }
            KeyCode::Enter => {
                self.mode = Mode::Normal;
                if self.source != 0 {
                    self.start_search();
                }
            }
            KeyCode::Backspace => {
                self.query.pop();
                self.sel = 0;
            }
            KeyCode::Up => self.move_sel(-1),
            KeyCode::Down => self.move_sel(1),
            KeyCode::Char(c) => {
                self.query.push(c);
                self.sel = 0;
            }
            _ => {}
        }
    }

    pub fn open_settings(&mut self) {
        self.mode = Mode::Settings;
        self.set_tab = 0;
        self.theme_state.select(Some(self.theme));
        self.dir_input = self.cfg.dir.clone();
        self.dir_msg = None;
    }

    fn close_settings(&mut self) {
        self.mode = Mode::Normal;
        self.save();
    }

    fn key_settings(&mut self, k: KeyEvent) {
        match k.code {
            KeyCode::Esc => self.close_settings(),
            KeyCode::Tab => self.set_tab = (self.set_tab + 1) % 3,
            KeyCode::BackTab => self.set_tab = (self.set_tab + 2) % 3,
            _ => match self.set_tab {
                0 => self.key_themes(k),
                1 => self.key_dir(k),
                _ => {}
            },
        }
    }

    fn key_themes(&mut self, k: KeyEvent) {
        let n = THEMES.len();
        match k.code {
            KeyCode::Up | KeyCode::Char('k') => self.theme = (self.theme + n - 1) % n,
            KeyCode::Down | KeyCode::Char('j') => self.theme = (self.theme + 1) % n,
            KeyCode::Enter => {
                self.close_settings();
                return;
            }
            _ => return,
        }
        self.theme_state.select(Some(self.theme));
    }

    fn key_dir(&mut self, k: KeyEvent) {
        match k.code {
            KeyCode::Char(c) => {
                self.dir_input.push(c);
                self.dir_msg = None;
            }
            KeyCode::Backspace => {
                self.dir_input.pop();
                self.dir_msg = None;
            }
            KeyCode::Down => {
                self.pick_i = (self.pick_i + 1) % PICKS.len();
                self.dir_input = PICKS[self.pick_i].to_string();
                self.dir_msg = None;
            }
            KeyCode::Up => {
                self.pick_i = (self.pick_i + PICKS.len() - 1) % PICKS.len();
                self.dir_input = PICKS[self.pick_i].to_string();
                self.dir_msg = None;
            }
            KeyCode::Enter => self.save_dir(),
            _ => {}
        }
    }

    fn save_dir(&mut self) {
        let v = self.dir_input.trim().to_string();
        let b = v.as_bytes();
        if v.is_empty() {
            self.dir_msg = Some(("Enter a folder path first.".into(), false));
            return;
        }
        let ok = v.starts_with('~')
            || v.starts_with('/')
            || (b.len() >= 3 && b[1] == b':' && (b[2] == b'\\' || b[2] == b'/'));
        if !ok {
            self.dir_msg = Some((
                "Start the path with ~, /, or a drive letter like C:\\.".into(),
                false,
            ));
            return;
        }
        let _ = std::fs::create_dir_all(expand(&v));
        self.cfg.dir = v;
        self.save();
        self.dir_msg = Some(("Saved. New downloads go to this folder.".into(), true));
        self.rescan();
    }

    // ---------- mouse ----------

    pub fn on_mouse(&mut self, m: MouseEvent) {
        if self.mode == Mode::Settings {
            return;
        }
        let (x, y) = (m.column, m.row);
        match m.kind {
            MouseEventKind::ScrollUp => self.move_sel(-1),
            MouseEventKind::ScrollDown => self.move_sel(1),
            MouseEventKind::Down(MouseButton::Left) => self.click(x, y, true),
            MouseEventKind::Drag(MouseButton::Left) => self.click(x, y, false),
            _ => {}
        }
    }

    fn click(&mut self, x: u16, y: u16, down: bool) {
        if inside(self.hit.progress, x, y) {
            let f = frac(self.hit.progress, x) as f64;
            if self.dur > 0.0 {
                self.seek_to(f * self.dur);
            }
            return;
        }
        if inside(self.hit.vol, x, y) {
            let f = frac(self.hit.vol, x);
            self.set_vol((f * NB_VOL as f32).round() / NB_VOL as f32);
            return;
        }
        if inside(self.hit.rv_bar, x, y) {
            let f = frac(self.hit.rv_bar, x);
            self.set_wet((f * 100.0).round() as u32);
            return;
        }
        if !down {
            return;
        }
        if inside(self.hit.gear, x, y) {
            self.open_settings();
            return;
        }
        if inside(self.hit.mute, x, y) {
            self.toggle_mute();
            return;
        }
        if inside(self.hit.lib_header, x, y) {
            self.lib_open = !self.lib_open;
            return;
        }
        let btn = self.hit.btns.iter().find(|(r, _)| inside(*r, x, y)).map(|(_, b)| *b);
        if let Some(b) = btn {
            match b {
                Btn::Prev => self.prev(),
                Btn::Back => self.seek_by(-10.0),
                Btn::Play => self.toggle_play(),
                Btn::Fwd => self.seek_by(10.0),
                Btn::Next => self.next(1),
            }
            return;
        }
        let sp = self.hit.speeds.iter().find(|(r, _)| inside(*r, x, y)).map(|(_, s)| *s);
        if let Some(s) = sp {
            self.set_speed(s);
            return;
        }
        let rv = self.hit.reverbs.iter().find(|(r, _)| inside(*r, x, y)).map(|(_, i)| *i);
        if let Some(i) = rv {
            self.set_reverb_preset(i);
            return;
        }
        let src = self.hit.sources.iter().find(|(r, _)| inside(*r, x, y)).map(|(_, i)| *i);
        if let Some(i) = src {
            self.set_source(i);
            return;
        }
        if inside(self.hit.tracks, x, y) {
            let idx = self.hit.tracks_offset + (y - self.hit.tracks.y) as usize;
            if idx < self.list().len() {
                if idx == self.sel {
                    self.activate(true);
                } else {
                    self.sel = idx;
                }
            }
        }
    }
}
