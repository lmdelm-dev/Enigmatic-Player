use std::fs::File;
use std::io::BufReader;
use std::path::Path;
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use rodio::source::SeekError;
use rodio::{Decoder, OutputStream, OutputStreamHandle, Sink, Source};

const COMB_MS: [f32; 4] = [29.7, 37.1, 41.1, 43.7];
// (delay scale, feedback) for: off, room, hall, cave, space
const PRESETS: [(f32, f32); 5] = [(1.0, 0.70), (1.0, 0.70), (1.6, 0.78), (2.4, 0.84), (3.2, 0.88)];
const TAP_KEEP: usize = 2048;
const FFT_N: usize = 1024;

/// Effect settings shared between the UI thread and the audio thread.
pub struct Fx {
    pub wet: AtomicU32,
    pub preset: AtomicU32,
}

/// Wraps a source: applies a live-adjustable reverb and copies samples
/// into a shared buffer so the UI can draw a real spectrum.
pub struct FxSource<S: Source<Item = f32>> {
    inner: S,
    fx: Arc<Fx>,
    tap: Arc<Mutex<Vec<f32>>>,
    channels: u16,
    rate: u32,
    bufs: Vec<Vec<f32>>,
    w: Vec<usize>,
    ch_idx: usize,
    chunk: Vec<f32>,
}

impl<S: Source<Item = f32>> FxSource<S> {
    pub fn new(inner: S, fx: Arc<Fx>, tap: Arc<Mutex<Vec<f32>>>) -> Self {
        let channels = inner.channels().max(1);
        let rate = inner.sample_rate();
        let max_len = (rate as f32 * 0.16) as usize + 2;
        FxSource {
            inner,
            fx,
            tap,
            channels,
            rate,
            bufs: vec![vec![0.0; max_len]; channels as usize * 4],
            w: vec![0; channels as usize],
            ch_idx: 0,
            chunk: Vec::with_capacity(512),
        }
    }
}

impl<S: Source<Item = f32>> Iterator for FxSource<S> {
    type Item = f32;

    fn next(&mut self) -> Option<f32> {
        let x = self.inner.next()?;
        let c = self.ch_idx;
        let wet = self.fx.wet.load(Ordering::Relaxed) as f32 / 100.0;
        let p = (self.fx.preset.load(Ordering::Relaxed) as usize).min(PRESETS.len() - 1);
        let (scale, fb) = PRESETS[p];
        let len = self.bufs[0].len();
        let wp = self.w[c];
        let mut acc = 0.0f32;

        for k in 0..4 {
            let delay = ((COMB_MS[k] * scale / 1000.0) * self.rate as f32) as usize;
            let delay = delay.clamp(1, len - 1);
            let rp = (wp + len - delay) % len;
            let buf = &mut self.bufs[c * 4 + k];
            let y = buf[rp];
            buf[wp] = x + y * fb;
            acc += y;
        }
        self.w[c] = (wp + 1) % len;

        let out = if wet > 0.0 {
            (x + acc * 0.25 * wet * 1.4).clamp(-1.0, 1.0)
        } else {
            x
        };

        if c == 0 {
            self.chunk.push(out);
            if self.chunk.len() >= 256 {
                if let Ok(mut b) = self.tap.try_lock() {
                    b.extend_from_slice(&self.chunk);
                    let n = b.len();
                    if n > TAP_KEEP {
                        b.drain(0..n - TAP_KEEP);
                    }
                }
                self.chunk.clear();
            }
        }

        self.ch_idx = (c + 1) % self.channels as usize;
        Some(out)
    }
}

impl<S: Source<Item = f32>> Source for FxSource<S> {
    fn current_frame_len(&self) -> Option<usize> {
        self.inner.current_frame_len()
    }
    fn channels(&self) -> u16 {
        self.channels
    }
    fn sample_rate(&self) -> u32 {
        self.rate
    }
    fn total_duration(&self) -> Option<Duration> {
        self.inner.total_duration()
    }
    fn try_seek(&mut self, pos: Duration) -> Result<(), SeekError> {
        self.inner.try_seek(pos)?;
        self.ch_idx = 0;
        self.chunk.clear();
        for b in self.bufs.iter_mut() {
            b.iter_mut().for_each(|v| *v = 0.0);
        }
        Ok(())
    }
}

pub struct Engine {
    _stream: OutputStream,
    handle: OutputStreamHandle,
    sink: Option<Sink>,
    fx: Arc<Fx>,
    tap: Arc<Mutex<Vec<f32>>>,
    rate: u32,
    volume: f32,
    speed: f32,
    paused: bool,
    window: Vec<f32>,
}

impl Engine {
    pub fn new() -> Result<Engine, String> {
        let (stream, handle) = OutputStream::try_default().map_err(|e| e.to_string())?;
        let window = (0..FFT_N)
            .map(|i| 0.5 - 0.5 * (2.0 * std::f32::consts::PI * i as f32 / (FFT_N as f32 - 1.0)).cos())
            .collect();
        Ok(Engine {
            _stream: stream,
            handle,
            sink: None,
            fx: Arc::new(Fx {
                wet: AtomicU32::new(0),
                preset: AtomicU32::new(0),
            }),
            tap: Arc::new(Mutex::new(Vec::new())),
            rate: 44100,
            volume: 0.7,
            speed: 1.0,
            paused: false,
            window,
        })
    }

    fn start(&mut self, path: &Path, skip: Option<Duration>) -> Result<(), String> {
        let file = File::open(path).map_err(|e| e.to_string())?;
        let dec = Decoder::new(BufReader::new(file)).map_err(|e| e.to_string())?;
        self.rate = dec.sample_rate();
        let sink = Sink::try_new(&self.handle).map_err(|e| e.to_string())?;
        sink.set_volume(self.volume);
        sink.set_speed(self.speed);
        let base = dec.convert_samples::<f32>();
        match skip {
            Some(d) => {
                let s = base.skip_duration(d);
                sink.append(FxSource::new(s, self.fx.clone(), self.tap.clone()));
            }
            None => {
                sink.append(FxSource::new(base, self.fx.clone(), self.tap.clone()));
            }
        }
        if self.paused {
            sink.pause();
        }
        if let Some(old) = self.sink.replace(sink) {
            old.stop();
        }
        Ok(())
    }

    pub fn play(&mut self, path: &Path) -> Result<(), String> {
        self.paused = false;
        let r = self.start(path, None);
        if let Ok(mut b) = self.tap.lock() {
            b.clear();
        }
        r
    }

    /// Seek to `t` seconds. Tries a native seek first, then re-opens the file and skips ahead.
    pub fn seek(&mut self, path: &Path, t: f64) -> bool {
        let d = Duration::from_secs_f64(t.max(0.0));
        if let Some(s) = &self.sink {
            if s.try_seek(d).is_ok() {
                return true;
            }
        }
        self.start(path, Some(d)).is_ok()
    }

    pub fn pause(&mut self) {
        self.paused = true;
        if let Some(s) = &self.sink {
            s.pause();
        }
    }

    pub fn resume(&mut self) {
        self.paused = false;
        if let Some(s) = &self.sink {
            s.play();
        }
    }

    pub fn set_volume(&mut self, v: f32) {
        self.volume = v.clamp(0.0, 1.5);
        if let Some(s) = &self.sink {
            s.set_volume(self.volume);
        }
    }

    /// Playback speed. Like a tape, this also changes pitch.
    pub fn set_speed(&mut self, v: f32) {
        self.speed = v.clamp(0.25, 3.0);
        if let Some(s) = &self.sink {
            s.set_speed(self.speed);
        }
    }

    pub fn set_reverb(&mut self, preset: usize, wet: u32) {
        self.fx.preset.store(preset as u32, Ordering::Relaxed);
        self.fx.wet.store(wet.min(100), Ordering::Relaxed);
    }

    pub fn finished(&self) -> bool {
        self.sink.as_ref().map(|s| s.empty()).unwrap_or(false)
    }

    /// Real spectrum of the audio that is playing, `bands` values in 0..1.
    pub fn spectrum(&self, bands: usize) -> Vec<f32> {
        let n = self.window.len();
        let samples: Vec<f32> = match self.tap.lock() {
            Ok(b) if b.len() >= n => b[b.len() - n..].to_vec(),
            _ => return vec![0.0; bands],
        };
        let sr = self.rate.max(8000) as f32;
        (0..bands)
            .map(|k| {
                let f = 60.0 * (12000.0f32 / 60.0).powf(k as f32 / (bands as f32 - 1.0));
                let f = f.min(sr * 0.45);
                let w = 2.0 * std::f32::consts::PI * f / sr;
                let coeff = 2.0 * w.cos();
                let (mut s1, mut s2) = (0.0f32, 0.0f32);
                for (i, x) in samples.iter().enumerate() {
                    let s = x * self.window[i] + coeff * s1 - s2;
                    s2 = s1;
                    s1 = s;
                }
                let power = (s1 * s1 + s2 * s2 - coeff * s1 * s2).max(0.0);
                let mag = power.sqrt() / (n as f32 / 4.0);
                let db = 20.0 * (mag + 1e-6).log10();
                ((db + 60.0) / 50.0).clamp(0.0, 1.0)
            })
            .collect()
    }
}
