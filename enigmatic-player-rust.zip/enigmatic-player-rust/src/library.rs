use std::path::{Path, PathBuf};
use std::process::Command;

use walkdir::WalkDir;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Provider {
    Local,
    YouTube,
    SoundCloud,
    Bandcamp,
}

impl Provider {
    pub const ALL: [Provider; 4] = [
        Provider::Local,
        Provider::YouTube,
        Provider::SoundCloud,
        Provider::Bandcamp,
    ];

    pub fn tag(self) -> &'static str {
        match self {
            Provider::Local => "L",
            Provider::YouTube => "Y",
            Provider::SoundCloud => "S",
            Provider::Bandcamp => "B",
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Provider::Local => "local files",
            Provider::YouTube => "youtube",
            Provider::SoundCloud => "soundcloud",
            Provider::Bandcamp => "bandcamp",
        }
    }
}

#[derive(Clone, Debug)]
pub struct Track {
    pub title: String,
    pub artist: String,
    pub secs: f64,
    pub path: Option<PathBuf>,
    pub url: Option<String>,
}

const EXTS: [&str; 7] = ["mp3", "flac", "ogg", "wav", "m4a", "aac", "mp4"];

/// Read title, artist and duration from a file. Falls back to the file name.
pub fn track_from_path(p: &Path) -> Track {
    use lofty::prelude::*;

    let stem = p
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("untitled")
        .to_string();
    let mut title = stem;
    let mut artist = String::from("unknown artist");
    let mut secs = 0.0;

    if let Ok(tf) = lofty::read_from_path(p) {
        secs = tf.properties().duration().as_secs_f64();
        if let Some(tag) = tf.primary_tag().or_else(|| tf.first_tag()) {
            if let Some(t) = tag.title() {
                if !t.trim().is_empty() {
                    title = t.to_string();
                }
            }
            if let Some(a) = tag.artist() {
                if !a.trim().is_empty() {
                    artist = a.to_string();
                }
            }
        }
    }

    Track {
        title,
        artist,
        secs,
        path: Some(p.to_path_buf()),
        url: None,
    }
}

/// Scan a folder recursively for audio files.
pub fn scan(dir: &Path) -> Vec<Track> {
    let mut out: Vec<Track> = WalkDir::new(dir)
        .follow_links(true)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .filter(|e| {
            e.path()
                .extension()
                .and_then(|x| x.to_str())
                .map(|x| EXTS.contains(&x.to_lowercase().as_str()))
                .unwrap_or(false)
        })
        .map(|e| track_from_path(e.path()))
        .collect();
    out.sort_by(|a, b| {
        (a.artist.to_lowercase(), a.title.to_lowercase())
            .cmp(&(b.artist.to_lowercase(), b.title.to_lowercase()))
    });
    out
}

pub fn has_ytdlp() -> bool {
    Command::new("yt-dlp")
        .arg("--version")
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

fn last_line(bytes: &[u8]) -> String {
    String::from_utf8_lossy(bytes)
        .lines()
        .rev()
        .find(|l| !l.trim().is_empty())
        .unwrap_or("")
        .trim()
        .to_string()
}

/// Search YouTube or SoundCloud, or list a pasted URL, using yt-dlp.
pub fn search_remote(provider: Provider, query: &str) -> Result<Vec<Track>, String> {
    let target = if query.starts_with("http://") || query.starts_with("https://") {
        query.to_string()
    } else {
        match provider {
            Provider::YouTube => format!("ytsearch10:{query}"),
            Provider::SoundCloud => format!("scsearch10:{query}"),
            _ => return Err("this source needs a track or album url".into()),
        }
    };

    let out = Command::new("yt-dlp")
        .args([
            "--flat-playlist",
            "--no-warnings",
            "--print",
            "%(title)s\t%(uploader,channel)s\t%(duration)s\t%(webpage_url,url)s",
        ])
        .arg(&target)
        .output()
        .map_err(|e| format!("yt-dlp not found: {e}"))?;

    if !out.status.success() {
        let msg = last_line(&out.stderr);
        return Err(if msg.is_empty() { "search failed".into() } else { msg });
    }

    let text = String::from_utf8_lossy(&out.stdout);
    let tracks: Vec<Track> = text
        .lines()
        .filter_map(|line| {
            let p: Vec<&str> = line.split('\t').collect();
            if p.len() < 4 || p[3] == "NA" || p[3].is_empty() {
                return None;
            }
            Some(Track {
                title: p[0].to_string(),
                artist: if p[1] == "NA" { "unknown artist".into() } else { p[1].to_string() },
                secs: p[2].parse::<f64>().unwrap_or(0.0),
                path: None,
                url: Some(p[3].to_string()),
            })
        })
        .collect();

    if tracks.is_empty() {
        Err("no results".into())
    } else {
        Ok(tracks)
    }
}

/// Download audio as mp3 into `dir` (needs yt-dlp and ffmpeg). Returns the saved file.
pub fn download(url: &str, dir: &Path) -> Result<PathBuf, String> {
    std::fs::create_dir_all(dir).map_err(|e| format!("cannot create folder: {e}"))?;
    let template = dir.join("%(title)s.%(ext)s");

    let out = Command::new("yt-dlp")
        .args([
            "-x",
            "--audio-format",
            "mp3",
            "--no-playlist",
            "--no-warnings",
            "--print",
            "after_move:filepath",
            "-o",
        ])
        .arg(&template)
        .arg(url)
        .output()
        .map_err(|e| format!("yt-dlp not found: {e}"))?;

    if !out.status.success() {
        let msg = last_line(&out.stderr);
        return Err(if msg.is_empty() { "download failed".into() } else { msg });
    }

    let path = PathBuf::from(last_line(&out.stdout));
    if path.exists() {
        Ok(path)
    } else {
        Err("download finished but the file was not found (is ffmpeg installed?)".into())
    }
}
