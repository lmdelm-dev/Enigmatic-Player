use ratatui::{
    layout::{Alignment, Constraint, Layout, Rect},
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, BorderType, Borders, Clear, List, ListItem, Paragraph},
    Frame,
};

use crate::app::{App, Btn, Mode, BANDS, NB_RV, NB_VOL, REVERBS, SPEEDS};
use crate::library::{Provider, Track};
use crate::themes::{Theme, THEMES};

const MIN_W: u16 = 80;
const MIN_H: u16 = 28;
const MAX_W: u16 = 110;

fn base(t: &Theme) -> Style {
    Style::default().fg(t.text).bg(t.bg)
}

fn fg(t: &Theme, c: Color) -> Style {
    Style::default().fg(c).bg(t.bg)
}

fn trunc(s: &str, w: usize) -> String {
    if s.chars().count() <= w {
        s.to_string()
    } else if w == 0 {
        String::new()
    } else {
        let mut o: String = s.chars().take(w - 1).collect();
        o.push('…');
        o
    }
}

fn fmt_time(s: f64) -> String {
    let s = s.max(0.0) as u64;
    format!("{:02}:{:02}", s / 60, s % 60)
}

fn pad(r: Rect, n: u16) -> Rect {
    Rect::new(
        r.x + n,
        r.y,
        r.width.saturating_sub(n * 2),
        r.height,
    )
}

fn same(a: &Track, b: &Track) -> bool {
    (a.path.is_some() && a.path == b.path) || (a.url.is_some() && a.url == b.url)
}

/// Builds one line of spans and remembers where each piece landed, for mouse hits.
struct RowB {
    y: u16,
    cur: u16,
    spans: Vec<Span<'static>>,
}

impl RowB {
    fn new(x: u16, y: u16) -> Self {
        RowB { y, cur: x, spans: Vec::new() }
    }
    fn put(&mut self, s: impl Into<String>, style: Style) -> Rect {
        let s: String = s.into();
        let w = s.chars().count() as u16;
        let r = Rect::new(self.cur, self.y, w, 1);
        self.cur += w;
        self.spans.push(Span::styled(s, style));
        r
    }
    fn line(self) -> Line<'static> {
        Line::from(self.spans)
    }
}

fn art_lines(t: &Theme, seed: usize, w: usize) -> Vec<Line<'static>> {
    let accent = [t.red, t.yellow, t.purple, t.green][seed % 4];
    let mut rows: Vec<Vec<Color>> = Vec::new();
    for r in 0..6usize {
        let mut row = vec![t.panel; w];
        match r {
            1 => {
                for c in 6..10 {
                    row[c] = accent;
                }
            }
            2 => {
                for c in 5..11 {
                    row[c] = accent;
                }
            }
            3 => {
                row = vec![accent; w];
            }
            4 | 5 => {
                row = vec![t.line; w];
                let g1 = (seed / 4 + r * 3) % w;
                let g2 = (seed / 7 + r * 5 + 4) % w;
                row[g1] = t.cyan;
                row[g2] = t.cyan;
            }
            _ => {}
        }
        rows.push(row);
    }
    rows.into_iter()
        .map(|row| {
            Line::from(
                row.into_iter()
                    .map(|c| Span::styled(" ", Style::default().bg(c)))
                    .collect::<Vec<_>>(),
            )
        })
        .collect()
}

fn bar_color(t: &Theme, k: usize) -> Color {
    match k {
        0..=2 => t.green,
        3..=5 => t.cyan,
        6..=8 => t.purple,
        _ => t.red,
    }
}

pub fn draw(f: &mut Frame, app: &mut App) {
    let t = THEMES[app.theme];
    let full = f.area();
    f.render_widget(Block::default().style(base(&t)), full);

    if full.width < MIN_W || full.height < MIN_H {
        let msg = format!("terminal too small: need {MIN_W}x{MIN_H}, have {}x{}", full.width, full.height);
        f.render_widget(
            Paragraph::new(msg).style(fg(&t, t.yellow)).alignment(Alignment::Center),
            Rect::new(full.x, full.y + full.height / 2, full.width, 1),
        );
        return;
    }

    let w = full.width.min(MAX_W);
    let area = Rect::new(full.x + (full.width - w) / 2, full.y, w, full.height);

    app.hit.btns.clear();
    app.hit.speeds.clear();
    app.hit.reverbs.clear();
    app.hit.sources.clear();

    let outer = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Thick)
        .border_style(fg(&t, t.cyan))
        .style(base(&t));
    let inner = outer.inner(area);
    f.render_widget(outer, area);

    let lib_c = if app.lib_open { Constraint::Min(6) } else { Constraint::Length(2) };
    let fill_c = if app.lib_open { Constraint::Length(0) } else { Constraint::Min(0) };
    let rows = Layout::vertical([
        Constraint::Length(1), // title bar
        Constraint::Length(8), // art + info
        Constraint::Length(2), // progress + controls
        Constraint::Length(4), // audio
        Constraint::Length(3), // search
        lib_c,                 // library
        fill_c,                // filler when library is hidden
        Constraint::Length(1), // status
    ])
    .split(inner);

    draw_titlebar(f, app, &t, rows[0]);
    draw_top(f, app, &t, rows[1]);
    draw_progress(f, app, &t, rows[2]);
    draw_audio(f, app, &t, rows[3]);
    draw_search(f, app, &t, rows[4]);
    draw_library(f, app, &t, rows[5]);
    draw_status(f, app, &t, rows[7]);

    if app.mode == Mode::Settings {
        draw_settings(f, app, &t, full);
    }
}

fn draw_titlebar(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let bar = Style::default().fg(t.dim).bg(t.panel);
    f.render_widget(Block::default().style(bar), r);

    let mut row = RowB::new(r.x + 1, r.y);
    row.put("● ", Style::default().fg(t.red).bg(t.panel));
    row.put("● ", Style::default().fg(t.yellow).bg(t.panel));
    row.put("● ", Style::default().fg(t.green).bg(t.panel));
    row.put(" ~/music - enigmatic player v1.4", bar);
    f.render_widget(Paragraph::new(row.line()), r);

    let label = "[ s: settings ] ";
    let lw = label.chars().count() as u16;
    let gx = r.x + r.width - lw;
    app.hit.gear = Rect::new(gx, r.y, lw, 1);
    f.render_widget(
        Paragraph::new(Span::styled(label, Style::default().fg(t.cyan).bg(t.panel))),
        app.hit.gear,
    );
}

fn draw_top(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let cols = Layout::horizontal([Constraint::Length(18), Constraint::Min(10)]).split(r);

    // album art
    let seed = app
        .now
        .as_ref()
        .map(|n| n.title.bytes().fold(7usize, |a, b| a.wrapping_mul(31).wrapping_add(b as usize)))
        .unwrap_or(3);
    let art_block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Thick)
        .border_style(fg(t, t.purple));
    let art_in = art_block.inner(cols[0]);
    f.render_widget(art_block, cols[0]);
    f.render_widget(Paragraph::new(art_lines(t, seed, art_in.width as usize)), art_in);

    // info
    let ir = Rect::new(cols[1].x + 2, cols[1].y, cols[1].width.saturating_sub(2), cols[1].height);
    let parts = Layout::vertical([
        Constraint::Length(1),
        Constraint::Length(1),
        Constraint::Length(1),
        Constraint::Min(1),
    ])
    .split(ir);
    let iw = ir.width as usize;

    let mut np = format!("now playing - {}", Provider::ALL[0].name());
    if (app.cfg.speed - 1.0).abs() > 0.001 {
        np.push_str(&format!(" - {:.2}x", app.cfg.speed));
    }
    if app.cfg.wet > 0 {
        np.push_str(&format!(" - reverb {}", REVERBS[app.cfg.reverb.min(4)].0));
    }
    f.render_widget(Paragraph::new(trunc(&np, iw)).style(fg(t, t.dim)), parts[0]);

    let (title, artist) = match &app.now {
        Some(n) => (n.title.clone(), n.artist.clone()),
        None => ("nothing playing".to_string(), "pick a track and press enter".to_string()),
    };
    f.render_widget(
        Paragraph::new(trunc(&title, iw)).style(fg(t, t.red).add_modifier(Modifier::BOLD)),
        parts[1],
    );
    f.render_widget(Paragraph::new(trunc(&artist, iw)).style(base(t)), parts[2]);

    // visualizer: 5 rows with eighth-block precision
    let glyphs = [' ', '▁', '▂', '▃', '▄', '▅', '▆', '▇', '█'];
    let vh = parts[3].height as i32;
    let mut lines: Vec<Line<'static>> = Vec::new();
    for r_i in 0..vh {
        let mut spans: Vec<Span<'static>> = Vec::new();
        for k in 0..BANDS {
            let v = app.bars.get(k).copied().unwrap_or(0.0);
            let h8 = (v * (vh as f32) * 8.0) as i32;
            let cell = (h8 - (vh - 1 - r_i) * 8).clamp(0, 8) as usize;
            let (g, col) = if cell == 0 && r_i == vh - 1 {
                ('▁', t.sel)
            } else {
                (glyphs[cell], bar_color(t, k))
            };
            spans.push(Span::styled(format!("{g}{g} "), fg(t, col)));
        }
        lines.push(Line::from(spans));
    }
    f.render_widget(Paragraph::new(lines).style(base(t)), parts[3]);
}

fn draw_progress(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let area = pad(r, 1);
    let bar = Rect::new(area.x, area.y, area.width, 1);
    app.hit.progress = bar;
    let w = bar.width as usize;
    let raw_filled: usize = if app.dur > 0.0 {
        ((app.pos / app.dur).clamp(0.0, 1.0) * w as f64).round() as usize
    } else {
        0
    };
    let filled = raw_filled.min(w);
    let line = Line::from(vec![
        Span::styled("█".repeat(filled), fg(t, t.red)),
        Span::styled("░".repeat(w - filled), fg(t, t.sel)),
    ]);
    f.render_widget(Paragraph::new(line), bar);

    let y = area.y + 1;
    f.render_widget(
        Paragraph::new(fmt_time(app.pos)).style(base(t)),
        Rect::new(area.x, y, 7, 1),
    );
    let dur_s = if app.dur > 0.0 { fmt_time(app.dur) } else { "--:--".to_string() };
    f.render_widget(
        Paragraph::new(dur_s).style(fg(t, t.dim)).alignment(Alignment::Right),
        Rect::new(area.x + area.width.saturating_sub(7), y, 7, 1),
    );

    // transport buttons, centered
    let play_label = if app.playing { "[||]" } else { "[> ]" };
    let items: [(&str, Btn); 5] = [
        ("[|<]", Btn::Prev),
        ("[-10]", Btn::Back),
        (play_label, Btn::Play),
        ("[+10]", Btn::Fwd),
        ("[>|]", Btn::Next),
    ];
    let total: u16 = items.iter().map(|(s, _)| s.chars().count() as u16).sum::<u16>() + 2 * 4;
    let start = area.x + area.width.saturating_sub(total) / 2;
    let mut row = RowB::new(start, y);
    for (i, (label, b)) in items.iter().enumerate() {
        if i > 0 {
            row.put("  ", base(t));
        }
        let rect = row.put(*label, fg(t, t.cyan));
        app.hit.btns.push((rect, *b));
    }
    f.render_widget(Paragraph::new(row.line()), Rect::new(start, y, total, 1));
}

fn draw_audio(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let blk = Block::default()
        .borders(Borders::TOP)
        .border_style(fg(t, t.line))
        .style(base(t));
    let inner = blk.inner(r);
    f.render_widget(blk, r);
    let x0 = inner.x + 1;
    let wdt = inner.width.saturating_sub(2);

    // volume
    {
        let y = inner.y;
        let mut row = RowB::new(x0, y);
        let muted = app.cfg.muted;
        app.hit.mute = row.put("vol    ", fg(t, if muted { t.red } else { t.green }));
        let on = if muted { 0 } else { (app.cfg.vol * NB_VOL as f32).round() as usize };
        let start = row.cur;
        for i in 0..NB_VOL {
            let col = if i < on {
                if i < 10 {
                    t.green
                } else if i < 14 {
                    t.yellow
                } else {
                    t.red
                }
            } else {
                t.sel
            };
            row.put("██ ", fg(t, col));
        }
        app.hit.vol = Rect::new(start, y, (NB_VOL * 3) as u16, 1);
        let pct = if muted { " mute".to_string() } else { format!(" {:>3}%", (app.cfg.vol * 100.0).round() as u32) };
        row.put(pct, base(t));
        f.render_widget(Paragraph::new(row.line()), Rect::new(x0, y, wdt, 1));
    }

    // speed
    {
        let y = inner.y + 1;
        let mut row = RowB::new(x0, y);
        row.put("speed  ", fg(t, t.dim));
        for s in SPEEDS.iter() {
            let active = (app.cfg.speed - *s).abs() < 0.001;
            let st = if active {
                Style::default().fg(t.purple).bg(t.sel)
            } else {
                fg(t, t.text)
            };
            let rect = row.put(format!(" {}x ", s), st);
            app.hit.speeds.push((rect, *s));
            row.put(" ", base(t));
        }
        row.put(format!("{:.2}x", app.cfg.speed), fg(t, t.cyan));
        f.render_widget(Paragraph::new(row.line()), Rect::new(x0, y, wdt, 1));
    }

    // reverb
    {
        let y = inner.y + 2;
        let mut row = RowB::new(x0, y);
        row.put("reverb ", fg(t, t.dim));
        for (i, (name, _)) in REVERBS.iter().enumerate() {
            let active = app.cfg.reverb == i;
            let st = if active {
                Style::default().fg(t.purple).bg(t.sel)
            } else {
                fg(t, t.text)
            };
            let rect = row.put(format!(" {} ", name), st);
            app.hit.reverbs.push((rect, i));
            row.put(" ", base(t));
        }
        row.put(" ", base(t));
        let start = row.cur;
        let on = ((app.cfg.wet as f32 / 100.0) * NB_RV as f32).round() as usize;
        for i in 0..NB_RV {
            row.put("██ ", fg(t, if i < on { t.purple } else { t.sel }));
        }
        app.hit.rv_bar = Rect::new(start, y, (NB_RV * 3) as u16, 1);
        row.put(format!(" {:>3}%", app.cfg.wet), base(t));
        f.render_widget(Paragraph::new(row.line()), Rect::new(x0, y, wdt, 1));
    }
}

fn draw_search(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let blk = Block::default()
        .borders(Borders::TOP)
        .border_style(fg(t, t.line))
        .style(base(t));
    let inner = blk.inner(r);
    f.render_widget(blk, r);

    let provider = Provider::ALL[app.source];
    let mut row = RowB::new(inner.x + 1, inner.y);
    row.put(format!("> search {} ", provider.tag()), fg(t, t.cyan));
    if app.query.is_empty() && app.mode != Mode::Search {
        row.put("press / to search", fg(t, t.dim));
    } else {
        row.put(app.query.clone(), base(t));
        if app.mode == Mode::Search {
            row.put("█", fg(t, t.cyan));
        }
    }
    f.render_widget(
        Paragraph::new(row.line()),
        Rect::new(inner.x + 1, inner.y, inner.width.saturating_sub(2), 1),
    );

    let msg = if app.status.is_empty() {
        "keys: / search  enter play  d download  1-4 source  s settings  q quit".to_string()
    } else {
        app.status.clone()
    };
    let w = inner.width.saturating_sub(2) as usize;
    let color = if app.busy { t.yellow } else { t.dim };
    f.render_widget(
        Paragraph::new(trunc(&msg, w)).style(fg(t, color)),
        Rect::new(inner.x + 1, inner.y + 1, inner.width.saturating_sub(2), 1),
    );
}

fn draw_library(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let blk = Block::default()
        .borders(Borders::TOP)
        .border_style(fg(t, t.line))
        .style(base(t));
    let inner = blk.inner(r);
    f.render_widget(blk, r);

    let header = Rect::new(inner.x, inner.y, inner.width, 1);
    app.hit.lib_header = header;
    let mut row = RowB::new(header.x + 1, header.y);
    row.put(
        format!("[{}] library", if app.lib_open { "-" } else { "+" }),
        fg(t, t.yellow),
    );
    row.put(" - sources and tracks (tab)", fg(t, t.dim));
    f.render_widget(Paragraph::new(row.line()), header);

    if !app.lib_open || inner.height < 2 {
        app.hit.tracks = Rect::default();
        return;
    }

    let body = Rect::new(inner.x, inner.y + 1, inner.width, inner.height - 1);
    let cols = Layout::horizontal([Constraint::Length(26), Constraint::Min(10)]).split(body);

    // sources
    let sblk = Block::default()
        .borders(Borders::RIGHT)
        .border_style(fg(t, t.sel))
        .style(base(t));
    let sin = sblk.inner(cols[0]);
    f.render_widget(sblk, cols[0]);
    for (i, p) in Provider::ALL.iter().enumerate() {
        if (i as u16) >= sin.height {
            break;
        }
        let y = sin.y + i as u16;
        let selected = i == app.source;
        let bg = if selected { t.sel } else { t.bg };
        let tag_col = match p {
            Provider::Local => t.green,
            Provider::YouTube => t.red,
            Provider::SoundCloud => t.yellow,
            Provider::Bandcamp => t.cyan,
        };
        let count = if i == 0 { format!(" ({})", app.local.len()) } else { String::new() };
        let rr = Rect::new(sin.x, y, sin.width, 1);
        let mut rb = RowB::new(rr.x, y);
        rb.put(if selected { "> " } else { "  " }, Style::default().fg(t.red).bg(bg));
        rb.put(format!("[{}]", p.tag()), Style::default().fg(tag_col).bg(bg));
        let name = trunc(&format!(" {}{}", p.name(), count), (sin.width as usize).saturating_sub(5));
        let used = rb.cur - rr.x;
        let name_w = name.chars().count() as u16;
        rb.put(name, Style::default().fg(t.text).bg(bg));
        let rest = sin.width.saturating_sub(used + name_w);
        rb.put(" ".repeat(rest as usize), Style::default().bg(bg));
        f.render_widget(Paragraph::new(rb.line()), rr);
        app.hit.sources.push((rr, i));
    }

    // tracks
    let area = cols[1];
    let now = app.now.clone();
    let items: Vec<ListItem<'static>> = {
        let tracks = app.list();
        let wd = area.width as usize;
        tracks
            .iter()
            .enumerate()
            .map(|(i, tr)| {
                let playing = now.as_ref().map(|n| same(n, tr)).unwrap_or(false);
                let marker = if playing { ">" } else { " " };
                let dur = if tr.secs > 0.0 { fmt_time(tr.secs) } else { "--:--".to_string() };
                let avail = wd.saturating_sub(dur.chars().count() + 2);
                let left = trunc(&format!("{} {:02}  {} - {}", marker, i + 1, tr.title, tr.artist), avail);
                let padn = avail.saturating_sub(left.chars().count());
                let st = if playing { fg(t, t.red) } else { fg(t, t.text) };
                ListItem::new(Line::from(vec![
                    Span::styled(format!("{}{} ", left, " ".repeat(padn)), st),
                    Span::styled(dur, fg(t, t.dim)),
                ]))
            })
            .collect()
    };

    if items.is_empty() {
        let provider = Provider::ALL[app.source];
        let msg = if app.source == 0 {
            if app.query.is_empty() {
                format!("no tracks in {}\nset the folder in settings (s)", app.cfg.dir)
            } else {
                "no matches. try an artist name.".to_string()
            }
        } else if !app.have_ytdlp {
            "yt-dlp not found. install it to use this source.".to_string()
        } else if provider == Provider::Bandcamp {
            "press / and paste a bandcamp track or album url".to_string()
        } else {
            format!("press / to search {}, then enter", provider.name())
        };
        f.render_widget(
            Paragraph::new(msg).style(fg(t, t.dim)),
            Rect::new(area.x + 1, area.y, area.width.saturating_sub(1), area.height),
        );
        app.hit.tracks = Rect::default();
        return;
    }

    app.list_state.select(Some(app.sel.min(items.len() - 1)));
    let list = List::new(items).highlight_style(Style::default().bg(t.sel).add_modifier(Modifier::BOLD));
    f.render_stateful_widget(list, area, &mut app.list_state);
    app.hit.tracks = area;
    app.hit.tracks_offset = app.list_state.offset();
}

fn draw_status(f: &mut Frame, app: &mut App, t: &Theme, r: Rect) {
    let st = Style::default().bg(t.panel);
    f.render_widget(Block::default().style(st), r);
    let vol = if app.cfg.muted {
        "vol muted".to_string()
    } else {
        format!("vol {}%", (app.cfg.vol * 100.0).round() as u32)
    };
    let fx = if app.cfg.wet > 0 {
        format!("reverb {} {}%", REVERBS[app.cfg.reverb.min(4)].0, app.cfg.wet)
    } else {
        "reverb off".to_string()
    };
    let line = Line::from(vec![
        Span::styled(format!(" {}", vol), st.fg(t.green)),
        Span::styled(format!("   speed {:.2}x - {}", app.cfg.speed, fx), st.fg(t.purple)),
        Span::styled(format!("   theme: {}", THEMES[app.theme].name), st.fg(t.dim)),
    ]);
    f.render_widget(Paragraph::new(line), r);
}

fn draw_settings(f: &mut Frame, app: &mut App, t: &Theme, area: Rect) {
    let w = 72u16.min(area.width.saturating_sub(2));
    let h = 24u16.min(area.height.saturating_sub(2));
    let pop = Rect::new(area.x + (area.width - w) / 2, area.y + (area.height - h) / 2, w, h);
    f.render_widget(Clear, pop);

    let blk = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Thick)
        .border_style(fg(t, t.purple))
        .title(Span::styled(" settings ", fg(t, t.yellow)))
        .style(base(t));
    let inner = blk.inner(pop);
    f.render_widget(blk, pop);

    let cols = Layout::horizontal([Constraint::Length(16), Constraint::Min(10)]).split(inner);

    // section list
    let nav_blk = Block::default()
        .borders(Borders::RIGHT)
        .border_style(fg(t, t.sel))
        .style(base(t));
    let nav_in = nav_blk.inner(cols[0]);
    f.render_widget(nav_blk, cols[0]);
    let names = ["themes", "local music", "about"];
    let nav: Vec<Line<'static>> = names
        .iter()
        .enumerate()
        .map(|(i, n)| {
            if i == app.set_tab {
                Line::from(Span::styled(
                    format!("> {:<12}", n),
                    Style::default().fg(t.red).bg(t.sel),
                ))
            } else {
                Line::from(Span::styled(format!("  {}", n), fg(t, t.text)))
            }
        })
        .collect();
    f.render_widget(Paragraph::new(nav), nav_in);

    let content = pad(cols[1], 1);
    match app.set_tab {
        0 => {
            let parts = Layout::vertical([Constraint::Length(2), Constraint::Min(3)]).split(content);
            f.render_widget(
                Paragraph::new("up/down: preview a theme\nenter: keep it   tab: next section").style(fg(t, t.dim)),
                parts[0],
            );
            let items: Vec<ListItem<'static>> = THEMES
                .iter()
                .map(|th| {
                    let sw = |c: Color| Span::styled("██", Style::default().fg(c).bg(th.bg));
                    ListItem::new(Line::from(vec![
                        sw(th.red),
                        Span::styled(" ", Style::default().bg(th.bg)),
                        sw(th.cyan),
                        Span::styled(" ", Style::default().bg(th.bg)),
                        sw(th.green),
                        Span::styled(" ", Style::default().bg(th.bg)),
                        sw(th.yellow),
                        Span::styled(format!("  {}", th.name), fg(t, t.text)),
                    ]))
                })
                .collect();
            let list = List::new(items).highlight_style(Style::default().bg(t.sel).add_modifier(Modifier::BOLD));
            f.render_stateful_widget(list, parts[1], &mut app.theme_state);
        }
        1 => {
            let mut lines: Vec<Line<'static>> = vec![
                Line::from(Span::styled("local music folder", fg(t, t.yellow))),
                Line::from(Span::styled(
                    "Downloads are saved here, and the",
                    fg(t, t.dim),
                )),
                Line::from(Span::styled(
                    "local files source reads from it.",
                    fg(t, t.dim),
                )),
                Line::from(""),
                Line::from(vec![
                    Span::styled("> ", fg(t, t.cyan)),
                    Span::styled(app.dir_input.clone(), base(t)),
                    Span::styled("█", fg(t, t.cyan)),
                ]),
            ];
            match &app.dir_msg {
                Some((m, ok)) => lines.push(Line::from(Span::styled(
                    m.clone(),
                    fg(t, if *ok { t.green } else { t.red }),
                ))),
                None => lines.push(Line::from("")),
            }
            lines.push(Line::from(""));
            lines.push(Line::from(Span::styled("up/down: quick picks   enter: save", fg(t, t.dim))));
            for p in crate::app::PICKS.iter() {
                lines.push(Line::from(Span::styled(format!("  {}", p), fg(t, t.text))));
            }
            lines.push(Line::from(""));
            lines.push(Line::from(vec![
                Span::styled("current: ", fg(t, t.dim)),
                Span::styled(app.cfg.dir.clone(), fg(t, t.cyan)),
            ]));
            f.render_widget(Paragraph::new(lines), content);
        }
        _ => {
            let key = |k: &str, d: &str| -> Line<'static> {
                Line::from(vec![
                    Span::styled(format!("{:<14}", k), fg(t, t.text)),
                    Span::styled(d.to_string(), fg(t, t.dim)),
                ])
            };
            let lines: Vec<Line<'static>> = vec![
                Line::from(Span::styled("about enigmatic player", fg(t, t.yellow))),
                Line::from(Span::styled("A pixel-style terminal music player.", base(t))),
                Line::from(""),
                Line::from(vec![
                    Span::styled("version   ", fg(t, t.dim)),
                    Span::styled("v1.4", base(t)),
                ]),
                Line::from(vec![
                    Span::styled("made by   ", fg(t, t.dim)),
                    Span::styled("Jamal Tiliouan", fg(t, t.cyan)),
                ]),
                Line::from(vec![
                    Span::styled("project   ", fg(t, t.dim)),
                    Span::styled("open source", fg(t, t.green)),
                ]),
                Line::from(""),
                key("space", "play or pause"),
                key("left / right", "seek 5 seconds"),
                key("up / down", "move in the list"),
                key("enter", "play, or download and play"),
                key("d", "download only"),
                key("/", "search"),
                key("tab", "hide or show library"),
                key("1-4", "choose source"),
                key("- / =", "volume"),
                key("m", "mute"),
                key("[ / ]", "slower and faster"),
                key("r  < >", "reverb preset and amount"),
                key("n / p", "next and previous"),
                key("q", "quit"),
            ];
            f.render_widget(Paragraph::new(lines), content);
        }
    }
}
